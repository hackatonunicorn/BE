"""
Email Templates Package
"""
